import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent, HomeComponent, PageNotFoundComponent, PricingFormComponent } from './components';

const routes: Routes = [
    { path: 'home', component: HomeComponent},
    { path: 'pricing-form', component: PricingFormComponent },
    { path: 'about', component: AboutComponent },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
