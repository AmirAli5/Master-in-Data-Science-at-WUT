export * from "./page-not-found.component";
