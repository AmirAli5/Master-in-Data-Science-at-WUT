import {
    HttpTestingController
} from "@angular/common/http/testing";
import { FormService } from './form.service';


describe('FormService', () => {
    let httpTestingController: HttpTestingController;
    let dataAccessService: FormService;
    let baseUrl = "'https://0xac5c3pyh.execute-api.us-east-1.amazonaws.com/prod/evaluation'";
   
    // beforeEach(() => {
    //   TestBed.configureTestingModule({
    //     imports: [HttpClientTestingModule]
    //   });
   
    //   httpTestingController = TestBed.get(HttpTestingController);
    // });
   
    // beforeEach(inject(
    //   [FormService],
    //   (service: FormService) => {
    //     dataAccessService = service;
    //   }
    // ));


});
