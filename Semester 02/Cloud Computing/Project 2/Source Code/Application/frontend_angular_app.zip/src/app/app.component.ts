import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    checked: boolean = false;
    title = 'motors-front';
    public isMenuCollapsed = true;
    
    constructor(public router: Router) {
        
    }

    public navigateTo(url: string): void {
        this.router.navigate([url]);
    }
}
