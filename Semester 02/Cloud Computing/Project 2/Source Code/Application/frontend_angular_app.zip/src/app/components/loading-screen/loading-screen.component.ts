﻿import { Component, Input } from "@angular/core";

@Component({
    selector: "loading-screen",
    styleUrls: ["./loading-screen.component.scss"],
    templateUrl: "./loading-screen.component.html",
})
export class LoadingScreenComponent {
    @Input() contentOverload: string = '';

    public getContents(): any {
        if (this.contentOverload != '')
        {
            return this.contentOverload;
        }
        else
        {
            return 'Working on it...';
        }
    }
}
