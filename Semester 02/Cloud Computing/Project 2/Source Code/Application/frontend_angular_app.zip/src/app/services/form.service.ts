import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EvaluationModelDto } from '../models';

@Injectable({
    providedIn: 'root'
})
export class FormService {
    private url: string = 'https://0xac5c3pyh.execute-api.us-east-1.amazonaws.com/prod/evaluation';

    constructor(private http: HttpClient) { }

    

    public async evaluateModel(dto: EvaluationModelDto): Promise<number> {
        const httpOptions = {
            headers: new HttpHeaders({ 
              'Access-Control-Allow-Origin':'*'
            })
          };
          
        return await this.http.put<number>(this.url, dto, httpOptions
            //,{
        //     headers: this.getRequestHeaders(),
        //     params: httpParams,
        // }
        )
        .toPromise<number>();
    }
    
    public getEngineTypes(): string[] {
        return ['Czterosuwowy', 'Elektryczny', 'Dwusuwowy'];
    }
    
    public getDriveTypes(): string[] {
        return ['Wał kardana', 'Łańcuch', 'Pas napędowy'];
    }

    public getOfferFrom(): string[] {
        return ['Osoby prywatnej','Firmy'];
    }

    public getGearTypes(): string[] {
        return ['Automatyczna', 'Bezstopniowa', 'Manualna', 'Półautomatyczna'];
    }
    
    public getFuelTypes(): string[] {
        return ['Benzyna', 'Elektryczny', 'Diesel'];
    }
    
    public getBodyTypes(): string[] {
        return ['Quad', 'Naked', 'Turystyczny', 'Sportowy', 'Skuter', 'Krosowy',
        'Chopper', 'Enduro', 'Cruiser', 'Motorower'];
    }
    
    public getColors(): string[] {
        return ['Czarny', 'Inny kolor', 'Biały', 'Niebieski', 'Czerwony', 'Szary',
        'Bordowy', 'Żółty', 'Zielony', 'Srebrny', 'Złoty', 'Brązowy',
        'Fioletowy', 'Beżowy'];
    }
    
    public getBrands(): string[] {
        return ['Kymco', 'Segway', 'Yamaha', 'Ducati', 'Kawasaki', 'Inny', 'Honda',
        'Harley-Davidson', 'CF Moto', 'Suzuki', 'Niu', 'KTM', 'Aprilia',
        'BMW', 'Can-Am', 'Keeway', 'Royal Enfield', 'Junak', 'Dniepr',
        'Piaggio', 'Hyosung', 'Husqvarna', 'MV AGUSTA', 'Baotian', 'Zipp',
        'Vespa', 'Polaris', 'Triumph', 'TGB', 'Romet', 'Zontes', 'Barton',
        'Beta', 'Moto Guzzi', 'WSK', 'Indian', 'ODES', 'EGL Eglmotor',
        'Benyco', 'Super Soco', 'Peugeot', 'Benelli', 'VELEX', 'Daelim',
        'Goes', 'Nitro Motors', 'KXD', 'Bajaj', 'Masai', 'Diabolini',
        'VOGE', 'Gas Gas', 'Rieju', 'iamelectric', 'Zongshen', 'X-Moto',
        'Loncin', 'Triango', 'Access', 'Derbi', 'SYM', 'Linhai', 'Sherco',
        'SHL', 'MZ', 'AJS', 'Victory', 'Malaguti', 'Jincheng',
        'Bombardier', 'Stels', 'SWM', 'Kingway', 'Askoll', 'Arctic Cat',
        'Yamasaki', 'Gilera', 'Bashan', 'Buell', 'Jawa', 'Brixton', 'RM',
        'BSA', 'Pannonia', 'Adler', 'Aixam', 'Peda', 'City-bike', 'Simson',
        'Aeon', 'Shineray', 'Cagiva', 'IŻ', 'Big Bear Choppers', 'LML',
        'UM', 'CPI', 'Garelli', 'Lifan', 'Bultaco', 'BOOM', 'Motron',
        'Elon Motors', 'KSR Moto', 'HISUN', 'MBK', 'Big Dog', 'Norton',
        'E-mio', 'Fantic', 'Mondial', 'SMC', 'Adly', 'CZ', 'Zumico',
        'Sachs']
    }

    public getModel(brand: string): string[] {
        switch(brand) {
            case 'Kymco':
                return ['MXU', 'Agility', 'Xciting', 'Downtown', 'Agility City A-C',
                'Inny', 'Maxxer', 'AK 550', 'Dink-Yager', 'Like', 'DT X360', 'UXV',
                'Dink', 'Grand Dink', 'People', 'Activ', 'X-Town', 'MyRoad',
                'MXer'];

            case 'Segway':
                return ['Fugleman UT10', 'Villain SX1' , 'Snarler AT6'];

            case 'Yamaha':
                return ['FZ', 'Drag Star', 'TDR', 'R6', 'YZF', 'FJR', 'XT', 'XJ', 'MT',
                'XVS', 'Road Star', 'Virago', 'Tracer', 'FZS', 'Tricity', 'R1',
                'X-max', 'YX', 'XC', 'TDM', 'R7', 'WR', 'YZ', 'XSR', 'XJR', 'XV',
                'Grizzly', 'TTR', 'Tmax', 'Thundercat', 'Aerox', 'R3', 'NIKEN',
                'R125', 'Inny', 'V Star', 'YFZ', 'YFM', 'Majesty', 'Midnight Star',
                'BT', 'Venture', 'NMAX', 'FJ', 'Tenere', 'Wolverine', 'XVZ', 'XTZ',
                'Royal Star', 'Raider', 'JOG', 'Super Tenere', 'SZR', 'FZR', 'YBR',
                'Cygnus', 'Warrior', 'XTX', 'SX', 'TX', 'Raptor', "D'elight",
                'Bulldog', 'V-MAX', 'GTS', 'Kodiak', 'PW', 'SR', 'DT', 'Wild star',
                'Neos', 'TZR'];

            case 'Ducati':
                return ['Multistrada', 'Scrambler', 'Monster', 'Diavel', 'Inny',
                'SuperSport', 'Streetfighter V4', 'Panigale V4', 'Panigale V4S',
                'Streetfighter V2', 'Panigale 899', 'SS 1000',
                'Streetfighter 1098', 'Ds 1000', '1199 Panigale', '959 Panigale',
                '748', 'Panigale 1299'];
            
            case 'Kawasaki':
                return ['ZX', 'Zephyr', 'Z', 'Ninja', 'Vulcan', 'ZXR', 'VN', 'KX', 'GTR',
                'Versys 650', 'Inny', 'Brute Force', 'ER', 'ZZR', 'ZR', 'KLE',
                'Spectre', 'Versys-X 300', 'LTD', 'Versys 1000', 'BN', '1000 GTR',
                'GPX', 'Ninja 250R', 'GPZ', 'KZ', 'EN', 'Estrella', 'EL', 'H2',
                'KLX', 'ZL', 'Ninja 300 ABS', 'KLR'];

            case 'Inny':
                return ['Inny'];

            case 'Honda':
                return ['XR', 'NSS', 'NX', 'Shadow', 'CBR', 'VF', 'NC', 'CBF', 'GL', 'CB',
                'Valkyrie', 'Deauville', 'VTX', 'VT', 'Hornet', 'VFR', 'MSX 125',
                'CRF', 'Varadero', 'Transalp', 'FES', 'X-ADV', 'ST', 'TRX', 'CMX',
                'NT', 'SH', 'VTR', 'S-Wing', 'Inny', 'PC', 'PCX', 'Z', 'XRV',
                'NTV', 'FMX', 'CTX', 'CLR', 'Pantheon', 'CA', 'CX', 'Vision', 'XL',
                'Bali', 'CN', 'Silver Wing', 'Zoomer', 'CG', 'SL', 'CM', 'DN-01',
                'PES', 'C', 'Super Cub', 'X8R', 'X11', 'FJS', 'NS',
                'Montesa Repsol', 'NSR'];

            case 'Harley-Davidson':
                return ['Fat Bob', 'Sportster', 'Road Glide', 'FLH Shovelhead', 'Softail',
                'Inny', 'Dyna Super Glide', 'Road King', 'Street 750', 'Dyna',
                'V-Rod', 'Heritage', 'Dyna Street Bob', 'Electra',
                'FLHX Street Glide', 'Electra Glide', 'Custom Low Rider',
                'FLHTCU Ultra', 'FLHXS Special', 'Springer', 'FXSB Breakout',
                'Night Train', 'Dyna Low', 'Fat Boy', 'Dyna Wide Glide',
                'FLH Electra Glide', 'WL', 'Custom', 'FLHS Electra Glide', 'XR'];

            case 'CF Moto':
                return ['ZForce', 'Inny', 'C-Force', 'Allroad', 'V3', 'X6'];

            case 'Suzuki':
                return ['Burgman', 'SV', 'GSR', 'VS', 'GS', 'Bandit', 'Inny', 'DL',
                'Intruder', 'VL 800 Volusia - Boulevard C50', 'GSX-R', 'Boulevard',
                'GSX-F - Katana', 'V-STROM', 'Savage', 'GN', 'GSX', 'Marauder',
                'Gladius', 'gsf-bandit', 'TU', 'XF', 'RV', 'RF', 'DR', 'Hayabusa',
                'Katana', 'VX', 'Kingquad', 'VZ',
                'VL 1500 Intruder LC - Boulevard C90', 'RM-Z', 'GZ',
                'VL 800 Volusia', 'GW 250'];

            case 'Niu':
                return ['N', 'M+', 'M', 'U'];

            case 'KTM':
                return ['LC 8', 'EXC', 'SXF', 'Duke', 'Super Adventure', 'SX', 'Inny',
                'RC 125', 'LC', 'RC 8', 'Super Duke', 'Freeride', 'Adventure',
                'SMC', 'RC 390'];
            
            case 'Aprilia':
                return ['SR', 'RS', 'Inny', 'Tuono', 'Shiver', 'Caponord', 'Pegaso',
                'Leonardo', 'Classic', 'Habana', 'Atlantic', 'Tuareg', 'Mana',
                'SX', 'RSV', 'RX', 'Mojito', 'Scarabeo'];

            case 'BMW':
                return ['RT', 'GS', 'K', 'G', 'S', 'F', 'LT', 'C1', 'R', 'C600 Sport',
                'XR', 'Adventure', 'C650 GT', 'Inny', 'CS'];

            case 'Can-Am':
                return ['Spyder', 'Renegade', 'Outlander Max', 'Outlander', 'Maverick',
                'Ryker', 'Inny', 'DS'];

            case 'Keeway':
                return ['Inny', 'Superlight', 'Vieste', 'RKF', 'F-act-Fact-NKD', 'Matrix',
                'Speed', 'Hurricane', 'TX'];

            case 'Royal Enfield':
                return ['Inny'];

            case 'Junak':
                return ['Inny', 'M', 'SC', '902', '125', '901', '121', 'RX One', '122'];

            case 'Dniepr':
                return ['MT-16', 'K-750', 'MT-10'];

            case 'Piaggio':
                return ['Vespa', 'Hexagon', 'Xevo', 'Liberty', 'X7', 'Inny', 'Beverly',
                'MP-3', 'Sfera', 'ZIP', 'FLY', 'X9', 'PX', 'X10', 'Ape 50 Van',
                'Medley', 'NRG', 'Ape Classic Van', 'Ciao'];
            
            case 'Hyosung':
                return ['GV', 'Cruise II', 'GT', 'Inny', 'GT Comet'];

            case 'Husqvarna':
                return ['TE', 'FE', 'Inny', '701', 'Svartpilen', 'FC', 'SM', '401', 'WRE',
                'TC', 'Vitpilen'];

            case 'MV AGUSTA':
                return ['Brutale', 'Inny', 'Turismo Veloce', 'Superveloce', 'F3',
                'Dragster', 'F4'];

            case 'Baotian':
                return ['BT49QT'];

            case 'Zipp':
                return ['Inny', 'ZIPP 125', 'Quantum', 'Simpli', 'TOPS', 'Volteno',
                'PRO RS50', 'Manic 125'];

            case 'Vespa':
                return ['LX', 'Sprint', 'GTS', 'Primavera', 'P', 'PX', 'Inny', 'Elettrica',
                'ET', 'GTV-LXV'];

            case 'Polaris':
                return ['RZR', 'Sportsman', 'Scrambler', 'Outlaw', 'Ranger XP', 'Inny',
                'Ranger', 'Ranger EV'];

            case 'Triumph':
                return ['Speedmaster', 'Thunderbird', 'Sprint', 'Scrambler',
                'Street Triple', 'Street Scrambler', 'Tiger', 'Rocket',
                'Speed Triple', 'Bonneville', 'Thruxton', 'Speed Twin', 'Trophy',
                'Bonneville Bobber', 'Street Twin', 'Trident', 'Legend TT',
                'Speed Four'];
            
            case 'TGB':
                return ['Blade', 'Inny'];

            case 'Romet':
                return ['RXC', 'Inny', 'Soft Chopper', '727', 'ZXT', 'RXL', 'K', 'RCR',
                'CRS', 'Kadet', '747', 'Zetka', 'Ogar 900', 'Z', 'R', 'Retro'];

            case 'Zontes':
                return ['125 U1', '125 G1 Spoke', '125 U', '125 G1 Aluminium', '125 Z2',
                '310T', '310M', '310R', '310X', '310V'];

            case 'Barton':
                return ['Hyper', 'Inny', 'Falcon', 'Cross', 'Z', 'Active'];

            case 'Beta':
                return ['RR', 'Evo', 'Motard', 'Euro', 'Inny'];

            case 'Moto Guzzi':
                return ['Nevada', 'V7', 'Stelvio', 'California', 'Norge', 'Inny', 'V9',
                'V11', 'Breva'];

            case 'WSK':
                return ['M21', 'M06', 'Inny'];

            case 'Indian':
                return ['Scout', 'Chief', 'Roadmaster', 'Chieftain', 'FTR', 'Vintage',
                'Springfield', 'Inny'];
            
            case 'ODES':
                return ['RM'];

            case 'EGL Eglmotor':
                return ['Madix'];

            case 'Benyco':
                return ['Inny'];

            case 'Super Soco':
                return ['TS', 'CPx', 'CUX', 'TC', 'TC MAX'];

            case 'Peugeot':
                return ['Citystar', 'Satelis', 'Speedfight', 'Metropolis', 'Geopolis',
                'Belville', 'Django', 'Inny', 'Tweet', 'Kisbee', 'Vivacity',
                'Ludix 2', 'Jet Force', 'Looxor', 'SV', 'Elystar Advantage'];

            case 'Benelli':
                return ['BN 125', 'Leoncino Trail', 'TRK 251', 'IMPERIALE 400', 'TRK 502',
                'Tornado Naked T', 'Leoncino', 'BN 251', '302 S', '502 C', 'TNT',
                'Inny', '752 S'];

            case 'VELEX':
                return ['Egreen'];

            case 'Daelim':
                return ['VL', 'Inny', 'VS', 'VT', 'Roadwin', 'NS'];
            
            case 'Goes':
                return ['Inny'];

            case 'Nitro Motors':
                return ['Inny'];

            case 'KXD':
                return ['Inny'];

            case 'Bajaj':
                return ['Dominar 400', 'Pulsar'];

            case 'Masai':
                return ['A', 'Inny'];

            case 'Diabolini':
                return ['Inny'];

            case 'VOGE':
                return ['300 DS', '300 AC'];

            case 'Gas Gas':
                return ['MC', 'EC', 'TXT', 'Inny'];
            
            case 'Rieju':
                return ['MRT', 'Tango', 'Tangoo!', 'Marathon', 'Inny', 'MRT Pro',
                'MRT Pro SM', 'Marathon Pro', 'MRT SM'];

            case 'iamelectric':
                return ['Horwin CR6', 'Life', 'iTank', 'X1 Double', 'S3 Double', 'Roma GT',
                'Robo-S', 'Hawk Double', 'Inny', 'Havana', 'MV Racer'];

            case 'Zongshen':
                return ['Inny'];

            case 'X-Moto':
                return ['Inny'];

            case 'Loncin':
                return ['Inny'];

            case 'Triango':
                return ['50'];

            case 'Access':
                return ['Tomahawk', 'Inny'];

            case 'Derbi':
                return ['GP1', 'Boulevard', 'Senda', 'GPR', 'Inny'];

            case 'SYM':
                return ['Inny', 'JET', 'Orbit', 'Fiddle', 'HD', 'GTS'];
            
            case 'Linhai':
                return ['ATV', '300', 'Inny', '260'];

            case 'Sherco':
                return ['Enduro', 'Trial'];

            case 'SHL':
                return ['Inny'];

            case 'MZ':
                return ['ETZ', 'ES', 'Inny', 'TS'];

            case 'AJS':
                return ['Inny'];

            case 'Victory':
                return ['Hammer', 'Inny', 'Vegas', 'Vision'];

            case 'Malaguti':
                return ['XTM 125', 'Dune', 'Inny', 'RST 125', 'Monte Pro', 'XSM'];

            case 'Jincheng':
                return ['JC 50'];
            
            case 'Bombardier':
                return ['Outlander', 'Traxter'];

            case 'Stels':
                return ['Inny'];
            
            case 'SWM':
                return ['SM 125 R', 'RS 500 R'];

            case 'Kingway':
                return ['Inny'];

            case 'Askoll':
                return ['eS3'];

            case 'Arctic Cat':
                return ['Inny', '400'];

            case 'Yamasaki':
                return ['Inny'];

            case 'Gilera':
                return ['Runner', 'Stalker 50', 'Nexus 500', 'SMT', 'Inny', 'GSM'];

            case 'Bashan':
                return ['Inny', 'BS250s-24', 'BS250s-11b', 'BS400s'];

            case 'Buell':
                return ['Inny'];
            
            case 'Jawa':
                return ['250', '350', 'Mustang 50', 'Inny'];

            case 'Brixton':
                return ['Felsberg', 'Cromwell'];

            case 'RM':
                return ['800 Duo', 'Inny'];

            case 'BSA':
                return ['C'];

            case 'Pannonia':
                return ['Inny'];

            case 'Adler':
                return ['Favorit'];

            case 'Aixam':
                return ['Inny'];

            case 'Peda':
                return ['Inny'];
            
            case 'City-bike':
                return ['Maxisport'];

            case 'Simson':
                return ['Inny'];

            case 'Aeon':
                return ['Cobra', 'Crossland'];

            case 'Shineray':
                return ['Inny', 'Extreme'];

            case 'Cagiva':
                return ['Navigator'];

            case 'IŻ':
                return ['Inny'];

            case 'Big Bear Choppers':
                return ['Athena'];

            case 'LML':
                return ['Star 125- 2T'];
                            
            case 'UM':
                return ['Renegade Commando', 'Renegade Sport'];

            case 'CPI':
                return ['SX', 'SM'];

            case 'Garelli':
                return ['Inny'];

            case 'Lifan':
                return ['LF'];

            case 'Bultaco':
                return ['Lobito'];

            case 'BOOM':
                return ['Fighter'];

            case 'Motron':
                return ['BREEZY'];

            case 'Elon Motors':
                return ['Elon One 80 Km'];
            
            case 'KSR Moto':
                return ['TW 125', 'Classic 50'];

            case 'HISUN':
                return ['Tactic 550'];

            case 'MBK':
                return ['Booster'];

            case 'Big Dog':
                return ['Inny'];

            case 'Norton':
                return ['Commando'];

            case 'E-mio':
                return ['Destina', 'Agile'];

            case 'Fantic':
                return ['Inny'];

            case 'Mondial'['HPS 125']:
                return ;
            
            case 'SMC':
                return ['Inny'];

            case 'Adly':
                return ['Inny'];

            case 'CZ':
                return ['175'];

            case 'Zumico':
                return ['ORS 250'];

            case 'Sachs':
                return ['ZX'];
            
            default:
                return ['Inny'];
        }
    }
}
