import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from 'src/app/services/form.service';

@Component({
    selector: 'app-pricing-form',
    templateUrl: './pricing-form.component.html',
    styleUrls: ['./pricing-form.component.scss']
})
export class PricingFormComponent implements OnInit {
    public form: FormGroup;
    public loading: boolean = true;
    public showingResults: boolean = false;
    public estimatedPrice: number;

    public offerFromTypes: string[];
    public brands: string[];
    public models: string[];
    public driveTypes: string[];
    public engineTypes: string[];
    public fuelTypes: string[];
    public gearTypes: string[];
    public bodyTypes: string[];
    public colors: string[];

    constructor(private fs: FormService) { }

    ngOnInit(): void {
        this.getTypesData();
        this.buildFormGroup();

        this.form.get('markaPojazdu').valueChanges.subscribe((x) => {this.models = this.fs.getModel(x)})
        this.loading = false;
    }

    private buildFormGroup(): void {
        this.form = new FormGroup({
            ofertaOd: new FormControl('Osoby prywatnej', Validators.required),
            kategoria: new FormControl('Motocykle', Validators.required),
            markaPojazdu: new FormControl(null, Validators.required),
            modelPojazdu: new FormControl(null, Validators.required),
            rokProdukcji: new FormControl(2000, [Validators.required, Validators.min(1900), Validators.max(2022)]),
            przebieg: new FormControl(0, [Validators.required, Validators.min(0)]),
            pojemnoscSkokowa: new FormControl(4.5, [Validators.required, Validators.min(0)]),
            moc: new FormControl(200, [Validators.required, Validators.min(0)]),
            rodzajNapedu: new FormControl(null,Validators.required),
            typSilnika: new FormControl(null, Validators.required),
            rodzajPaliwa: new FormControl(null,Validators.required),
            skrzyniaBiegow: new FormControl(null,Validators.required),
            typNadwozia: new FormControl(null,Validators.required),
            kolor: new FormControl(null,Validators.required)
        });
    }

    public json(): void {
        console.log(this.form)
    }

    public async submitForm(): Promise<void> {
        this.loading = true;
        this.form.disable();
        let data = this.form.getRawValue()
        this.estimatedPrice = await this.fs.evaluateModel(data)
        this.showingResults = true;
        this.loading = false;
    }

    public resetForm(): void {
        this.form.reset();
        this.buildFormGroup();
    }

    private getTypesData(): void {
        this.offerFromTypes = this.fs.getOfferFrom();
        this.brands = this.fs.getBrands();
        this.driveTypes = this.fs.getDriveTypes();
        this.engineTypes = this.fs.getEngineTypes();
        this.fuelTypes = this.fs.getFuelTypes();
        this.gearTypes = this.fs.getGearTypes();
        this.bodyTypes= this.fs.getBodyTypes();
        this.colors = this.fs.getColors();
    };

    public backToNewForm(): void {
        this.resetForm();
        setTimeout(() => this.form.enable(), 100);
        this.showingResults = false;
    }
}
