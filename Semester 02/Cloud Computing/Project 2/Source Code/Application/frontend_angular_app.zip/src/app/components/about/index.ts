export * from "./about.component";
