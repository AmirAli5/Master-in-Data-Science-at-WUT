export class EvaluationModelDto {
    public ofertaOd: string;
    public kategoria: string;
    public markaPojazdu: string;
    public modelPojazdu: string;
    public rokProdukcji: number;
    public przebieg: number;
    public pojemnoscSkokowa: number;
    public moc: number;
    public rodzajNapedu: string;
    public typSilnika: string;
    public rodzajPaliwa: string;
    public skrzyniaBiegow: string;
    public typNadwozia: string;
    public kolor: string;
}