export * from "./footer.component";
