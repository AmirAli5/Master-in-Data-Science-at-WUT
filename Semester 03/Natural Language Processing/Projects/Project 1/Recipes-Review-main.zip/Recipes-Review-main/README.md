![NLP](https://pbs.twimg.com/media/FgeSxwyXEAEnSO1?format=jpg&name=medium)

Overleaf Link:
https://www.overleaf.com/read/zsbjdjkgqwrm
